"""Authenticated node transport."""
